
public class EmployeeTest 
{

    public static void main(String[] args) 
    {
        final int arraySize = 5;
        CommissionEmployee[] employeeArray = new CommissionEmployee[arraySize];
        employeeArray[0] = new CommissionEmployee("Sue", "Jones", "222-22-2222", "CE17", 10000, 0.06); 
        employeeArray[1] = new BasePlusCommissionEmployee("Bob", "Lewis", "333-33-3333", "BC19", 5000, 0.04, 300);
        employeeArray[2] = new BasePlusCommissionEmployee("Mary", "Sanchez", "123-45-6789", "AL29", 6500, 0.05, 250);
        employeeArray[3] = new CommissionEmployee("Pat","Marguet", "555-55-5555", "AU92", 8000,0.05);
        employeeArray[4] = new CommissionEmployee("Mick", "Johnson", "987-65-4321", "NK87", 11000, 0.07);
        
        for(int i = 0; i < arraySize; i++)
        {
            System.out.println(employeeArray[i] + "\n");
        }
    }// end class
    
}// main
